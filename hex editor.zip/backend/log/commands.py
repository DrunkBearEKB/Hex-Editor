from enum import Enum


class Command(Enum):
    INSERT = 1
    REFACTOR = 2
    DELETE = 3
